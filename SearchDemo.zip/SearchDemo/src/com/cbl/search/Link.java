package com.cbl.search;

public class Link {

}
