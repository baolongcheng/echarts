package com.cbl.search;

import java.util.Random;

public class InsertSortDemo {
	
	public static void main(String[] args) {
		int[] arr = new int[10];
		for (int i = 9; i >= 0; i--) {
			arr[i] = new Random().nextInt(100);
			System.out.println(arr[i]);
		}
		System.out.println("-----------------------------");
		sort(arr);
	}
	
	
	public static void sort(int[] array){
		
		for (int i = 1; i < array.length; i++) {
			int temp = array[i];
			int in = i ; 
			while(in>0 && array[in-1]> temp){
				array[in] = array[in-1];
				in--;
			}
			array[in] = temp;
		}
		for (int i = 0; i < array.length; i++) {
		  System.out.println(array[i]);	
		}
	}

}
