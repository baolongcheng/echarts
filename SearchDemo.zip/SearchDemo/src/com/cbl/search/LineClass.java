package com.cbl.search;

public class LineClass {
	
	private int id ;
	
	private int  a ;
	
	private int b ;
	
	private boolean visited;

	public LineClass(int a, int b) {
		this.a = a;
		this.b = b;
	}
	
	

	public LineClass(int id, int a, int b) {
		this.id = id;
		this.a = a;
		this.b = b;
	}



	public LineClass() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getA() {
		return a;
	}

	public boolean isVisited() {
		return visited;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public void setVisited(boolean visited) {
		this.visited = visited;
	}



	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	

	@Override
	public String toString() {
		return "LineClass [id=" + id + ", a=" + a + ", b=" + b + ", visited=" + visited + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + a;
		result = prime * result + b;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LineClass other = (LineClass) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
	
}
