package com.cbl.search;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;

public class SearchDemo {

	public static void main(String[] args) {

		Set<LineClass> lineClassSet = new HashSet<>();

		for (int i = 0; i < 100; i++) {
			int a = new Random().nextInt(100)+1;
			int b = new Random().nextInt(100)+1;
			while(a == b){
				b = new Random().nextInt(100)+1;
			}
			lineClassSet.add(new LineClass(i,a,b));
		}
		
		List<LineClass> links = new LinkedList<>(lineClassSet);
		
		
		boolean hasCircle = whetherHasCircle(links) ;
		System.out.println(hasCircle);
		Map<Integer,List<LineClass>> lineMap = new LinkedHashMap<>();
		seperateWithSiteId(links, lineMap);
		
		
		//用来存放所有的唯一id
		List<Integer> linkIds = new LinkedList<>();
		
		//用来存放所有的站点id
		LinkedList<Integer> siteIds = new LinkedList<>();
		int leastSiteId = getLeastUseSiteId(lineMap);
		siteIds.add(leastSiteId);
		for (LineClass lineClass : links) {
			System.out.println(lineClass);
		}
		
		System.out.println("--------------------------------------------");
		//获取站点使用次数最少的站点的第一个站点，然后找出相关的连纤，然后找出对应的宿站点，找出对应的次数使用最少的站点然后取第一个，
		getCircle(links, lineMap, leastSiteId, linkIds, siteIds);
		
		//linkIds包含了形成环的id；
		int start = siteIds.getFirst() ;
		for (Integer linkId : linkIds) {
			for (LineClass lineClass : links) {
				if(lineClass.getId() == linkId){
					if(start ==  lineClass.getA()){
						System.out.println(lineClass.getA() + "------->" + lineClass.getB() );
						start = lineClass.getB();
					}
					else{
						System.out.println(lineClass.getB() + "------->" + lineClass.getA() );
						start = lineClass.getA();
					}
					break ;
				}
			}
		}
		// getCircle(links,lineMap);

	}

	private static void getCircle(List<LineClass> links, Map<Integer, List<LineClass>> lineMap, int leastSiteId,
			List<Integer> linkIds, LinkedList<Integer> siteIds) {
		int siteId = getLeastUseInCircle(lineMap, siteIds,leastSiteId);
		if(siteId == -1){
			return ;
		}
		boolean isCircle = false;
		//List<Integer> listTmp = new ArrayList<>(siteIds.subList(siteIds.size()-2, siteIds.size()));
		for (LineClass lineClass : links) {
			if(siteIds.contains(lineClass.getA()) && siteIds.contains(lineClass.getB()) && !linkIds.contains(lineClass.getId())){
				linkIds.add(lineClass.getId());
				break ;
			}
		}
		//收尾相连，成环
		if(siteIds.getFirst().equals(siteIds.getLast()))
		{
			isCircle = true ;
		}
		if(!isCircle){
			getCircle(links, lineMap, siteId, linkIds, siteIds);
		};
	}

	private static int getLeastUseInCircle(Map<Integer, List<LineClass>> lineMap,List<Integer> siteIds, int leastSiteId) {
		
		List<LineClass> list = lineMap.get(leastSiteId);
		
		//获取指定站点的链路的另一端使用次数最少的链路
		
		Set<Integer> ids = new HashSet<>();
		
		if(list != null){
			
			for (LineClass lineClass : list) {
				ids.add(lineClass.getA());
				ids.add(lineClass.getB());
			}
		}
		
		
		int minCount = Integer.MAX_VALUE; 
		int siteId = -1;
		Iterator<Entry<Integer, List<LineClass>>> iterator = lineMap.entrySet().iterator();
		while(iterator.hasNext()){
			Entry<Integer, List<LineClass>> next = iterator.next();
			if(ids.contains(next.getKey()) && !siteIds.contains(next.getKey())){
				if(next.getValue().size() < minCount){
					minCount = next.getValue().size();
					siteId = next.getKey();
				}
			}
		}
		if(siteId != -1)
		siteIds.add(siteId);
		return siteId;
	}

	private static int getLeastUseSiteId(Map<Integer, List<LineClass>> lineMap) {
		int minCount = Integer.MAX_VALUE; 
		int siteId = -1;
		Iterator<Entry<Integer, List<LineClass>>> iterator = lineMap.entrySet().iterator();
		while(iterator.hasNext()){
			Entry<Integer, List<LineClass>> next = iterator.next();
			int count = next.getValue().size();
			if(count < minCount){
				minCount = count;
				siteId = next.getKey();
			}
		}
		return siteId;
	}
	
	private static boolean whetherHasCircle(List<LineClass> links) {
		Map<Integer,List<LineClass>> lineMap = new LinkedHashMap<>();
		seperateWithSiteId(links, lineMap);
		boolean hasSingleSite = removeSingleUse(links, lineMap,false);
		if(hasSingleSite){
			whetherHasCircle(links);
		}
		
		return links.size() != 0;
	}

	private static boolean removeSingleUse(List<LineClass> links, Map<Integer, List<LineClass>> lineMap, boolean hasSingleSite) {
		Iterator<Entry<Integer, List<LineClass>>> iterator = lineMap.entrySet().iterator();
		while(iterator.hasNext()){
			Entry<Integer, List<LineClass>> next = iterator.next();
			if(next.getValue().size() < 2){
				links.removeAll(next.getValue());
				iterator.remove();
				hasSingleSite = true ;
			}
		}
		return hasSingleSite;
	}

	private static void seperateWithSiteId(List<LineClass> links, Map<Integer, List<LineClass>> lineMap) {
		for (LineClass lineClass : links) {
			
			List<LineClass> lineClasses1 = lineMap.get(lineClass.getA());
			if(lineClasses1 == null)
			{
				lineClasses1 = new ArrayList<>();
				lineMap.put(lineClass.getA(), lineClasses1);
			}
			lineClasses1.add(lineClass);
			
			List<LineClass> lineClasses2 = lineMap.get(lineClass.getB());
			if(lineClasses2 == null)
			{
				lineClasses2 = new ArrayList<>();
				lineMap.put(lineClass.getB(), lineClasses2);
			}
			lineClasses2.add(lineClass);
		}
	}


	private static void reatainAllTest() {
		Set<LineClass> lineClasses = new HashSet<>();

		for (int i = 0; i < 100; i++) {
			lineClasses.add(new LineClass(new Random().nextInt(100), new Random().nextInt(100)));
		}

		List<LineClass> line = new ArrayList<>(lineClasses);
		for (LineClass lineClass : line) {
			System.out.println(lineClass);
		}
		LineClass first = line.remove(0);
		Set<Integer> set1 = new HashSet<>();
		set1.add(first.getA());
		set1.add(first.getB());
		System.out.println("first：" + first);
		System.out.println("-------------------------------");
		Set<Integer> set2 = new HashSet<>();
		for (LineClass lineClass : line) {
			set2 = new HashSet<>();
			set2.add(lineClass.getA());
			set2.add(lineClass.getB());
			set2.retainAll(set1);
			if (set2.size() > 0) {
				System.out.println(lineClass);
			}
		}
	}

}
